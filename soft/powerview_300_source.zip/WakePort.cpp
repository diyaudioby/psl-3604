#pragma hdrstop

#include "WakePort.h"

#pragma package(smart_init)

//--------------------------- �����������: ----------------------------------

__fastcall TWakePort::TWakePort()
{
  SetBaudRate(BAUD);
}

//---------------------------- ����������: ----------------------------------

__fastcall TWakePort::~TWakePort()
{
//
}

//---------------------------------------------------------------------------
//------------------------- ����������� �������: ----------------------------
//---------------------------------------------------------------------------

//GetVIPmax(v, i, p)
//GetVIavg(v, i)
//GetStat(s)
//GetFan(f, t)

//GetPar(n, v)
//SetPar(cb->Tag, cb->Checked)
//SetVIPmax(ROUND(v, i, p)
//SetPre(n, v, i)
//SetCal(n, v)
//GetPre(n, v, i)
//GetCal(n, v)

//----------------------------- CMD_SET_VI: ---------------------------------

void __fastcall TWakePort::SetVI(int v, int i, bool on)
{
  _ENTER_COMMAND(CmdCrSec)
  NewCmd(CMD_SET_VI, "SetVI");
  AddWord(v);
  AddWord(i);
  AddByte(on? 1 : 0);
  SendCmd(0);
  _LEAVE_COMMAND(CmdCrSec)
}

//---------------------------- CMD_GET_VI: ----------------------------------

void __fastcall TWakePort::GetVI(int &v, int &i)
{
  _ENTER_COMMAND(CmdCrSec)
  NewCmd(CMD_GET_VI, "GetVI");
  SendCmd(0);
  v = GetWord();
  i = GetWord();
  _LEAVE_COMMAND(CmdCrSec)
}

//---------------------------- CMD_GET_STAT: --------------------------------

void __fastcall TWakePort::GetStat(int &s)
{
  _ENTER_COMMAND(CmdCrSec)
  NewCmd(CMD_GET_STAT, "GetStat");
  SendCmd(0);
  s = GetByte();
  _LEAVE_COMMAND(CmdCrSec)
}

//-------------------------- CMD_GET_VI_AVG: --------------------------------

void __fastcall TWakePort::GetVIavg(int &v, int &i)
{
  _ENTER_COMMAND(CmdCrSec)
  NewCmd(CMD_GET_VI_AVG, "GetVIavg");
  SendCmd(0);
  v = GetWord();
  i = GetWord();
  _LEAVE_COMMAND(CmdCrSec)
}

//------------------------- CMD_GET_VI_FAST: --------------------------------

void __fastcall TWakePort::GetVIfast(int &v, int &i)
{
  _ENTER_COMMAND(CmdCrSec)
  NewCmd(CMD_GET_VI_FAST, "GetVIfast");
  SendCmd(0);
  v = GetWord();
  i = GetWord();
  _LEAVE_COMMAND(CmdCrSec)
}

//-------------------------- CMD_SET_VIP_MAX: -------------------------------

void __fastcall TWakePort::SetVIPmax(int v, int i, int p)
{
  _ENTER_COMMAND(CmdCrSec)
  NewCmd(CMD_SET_VIP_MAX, "SetVIPmax");
  AddWord(v);
  AddWord(i);
  AddWord(p);
  SendCmd(0);
  _LEAVE_COMMAND(CmdCrSec)
}

//------------------------- CMD_GET_VIP_MAX: --------------------------------

void __fastcall TWakePort::GetVIPmax(int &v, int &i, int &p)
{
  _ENTER_COMMAND(CmdCrSec)
  NewCmd(CMD_GET_VIP_MAX, "GetVIPmax");
  SendCmd(0);
  v = GetWord();
  i = GetWord();
  p = GetWord();
  _LEAVE_COMMAND(CmdCrSec)
}

//---------------------------- CMD_SET_PRE: ---------------------------------

void __fastcall TWakePort::SetPre(int p, int v, int i)
{
  _ENTER_COMMAND(CmdCrSec)
  NewCmd(CMD_SET_PRE, "SetPre");
  AddByte(p);
  AddWord(v);
  AddWord(i);
  SendCmd(0);
  _LEAVE_COMMAND(CmdCrSec)
}

//---------------------------- CMD_GET_PRE: ---------------------------------

void __fastcall TWakePort::GetPre(int p, int &v, int &i)
{
  _ENTER_COMMAND(CmdCrSec)
  NewCmd(CMD_GET_PRE, "GetPre");
  AddByte(p);
  SendCmd(0);
  v = GetWord();
  i = GetWord();
  _LEAVE_COMMAND(CmdCrSec)
}

//---------------------------- CMD_SET_PAR: ---------------------------------

void __fastcall TWakePort::SetPar(int p, int v)
{
  _ENTER_COMMAND(CmdCrSec)
  NewCmd(CMD_SET_PAR, "SetPar");
  AddByte(p);
  AddWord(v);
  SendCmd(0);
  _LEAVE_COMMAND(CmdCrSec)
}

//---------------------------- CMD_GET_PAR: ---------------------------------

void __fastcall TWakePort::GetPar(int p, int &v)
{
  _ENTER_COMMAND(CmdCrSec)
  NewCmd(CMD_GET_PAR, "GetPar");
  AddByte(p);
  SendCmd(0);
  v = GetWord();
  _LEAVE_COMMAND(CmdCrSec)
}

//---------------------------- CMD_GET_FAN: ---------------------------------

void __fastcall TWakePort::GetFan(int &s, int &t)
{
  _ENTER_COMMAND(CmdCrSec)
  NewCmd(CMD_GET_FAN, "GetFan");
  SendCmd(0);
  s = GetByte();
  t = GetWord();
  _LEAVE_COMMAND(CmdCrSec)
}

//---------------------------- CMD_SET_DAC: ---------------------------------

void __fastcall TWakePort::SetDAC(int cv, int ci)
{
  _ENTER_COMMAND(CmdCrSec)
  NewCmd(CMD_SET_DAC, "SetDAC");
  AddWord(cv);
  AddWord(ci);
  SendCmd(0);
  _LEAVE_COMMAND(CmdCrSec)
}

//---------------------------- CMD_GET_ADC: ---------------------------------

void __fastcall TWakePort::GetADC(int &cv, int &ci)
{
  _ENTER_COMMAND(CmdCrSec)
  NewCmd(CMD_GET_ADC, "GetADC");
  SendCmd(0);
  cv = GetWord();
  ci = GetWord();
  _LEAVE_COMMAND(CmdCrSec)
}

//---------------------------- CMD_SET_CAL: ---------------------------------

void __fastcall TWakePort::SetCal(int c, int v)
{
  _ENTER_COMMAND(CmdCrSec)
  NewCmd(CMD_SET_CAL, "SetCal");
  AddByte(c);
  AddWord(v);
  SendCmd(0);
  _LEAVE_COMMAND(CmdCrSec)
}

//---------------------------- CMD_GET_CAL: ---------------------------------

void __fastcall TWakePort::GetCal(int c, int &v)
{
  _ENTER_COMMAND(CmdCrSec)
  NewCmd(CMD_GET_CAL, "GetCal");
  AddByte(c);
  SendCmd(0);
  v = GetWord();
  _LEAVE_COMMAND(CmdCrSec)
}

//---------------------------------------------------------------------------

