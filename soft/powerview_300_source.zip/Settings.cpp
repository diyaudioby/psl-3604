#include <vcl.h>
#pragma hdrstop

#include "Settings.h"
#include "Main.h"

#pragma package(smart_init)
#pragma link "FloatEdit"
#pragma resource "*.dfm"
TSettingsForm *SettingsForm;

//---------------------------------------------------------------------------

__fastcall TSettingsForm::TSettingsForm(TComponent* Owner)
  : TForm(Owner)
{
}

//------------------------------- ReadPar: ----------------------------------

int __fastcall TSettingsForm::ReadPar(int n)
{
  int v;
  MainForm->WakePort->GetPar(n, v);
  return(v);
}

//----------------------------- Form create: --------------------------------

void __fastcall TSettingsForm::FormCreate(TObject *Sender)
{
  cbAutoConnect->Checked = MainForm->FAutoConnect;
  cbAutoLoad->Checked = MainForm->FAutoLoad;
  cbSample->ItemIndex = (MainForm->FSample - 20) / 20;
  cbAutoScroll->Checked = MainForm->FAutoScroll;

  Lock = 1;

  cbPAR_LOCK->Tag = PAR_LOCK;
  fePAR_OVP->Tag = PAR_OVP;
  fePAR_OCP->Tag = PAR_OCP;
  fePAR_OPP->Tag = PAR_OPP;
  fePAR_DEL->Tag = PAR_DEL;
  fePAR_OTP->Tag = PAR_OTP;
  fePAR_FNL->Tag = PAR_FNL;
  fePAR_FNH->Tag = PAR_FNH;
  cbPAR_TRC->Tag = PAR_TRC;
  cbPAR_CON->Tag = PAR_CON;
  cbPAR_POW->Tag = PAR_POW;
  cbPAR_SET->Tag = PAR_SET;
  cbPAR_GET->Tag = PAR_GET;
  cbPAR_APV->Tag = PAR_APV;
  cbPAR_APC->Tag = PAR_APC;
  cbPAR_PRC->Tag = PAR_PRC;
  cbPAR_DNP->Tag = PAR_DNP;
  cbPAR_OUT->Tag = PAR_OUT;
  cbPAR_SND->Tag = PAR_SND;
  cbPAR_ENR->Tag = PAR_ENR;
  cbPAR_SPL->Tag = PAR_SPL;
  fePAR_INF->Tag = PAR_INF;
  edPAR_TIM->Tag = PAR_TIM;

  feMaxV->Value = MainForm->MaxV;
  feMaxI->Value = MainForm->MaxI;

  PreV[0] = fePrv0; PreI[0] = fePri0;
  PreV[1] = fePrv1; PreI[1] = fePri1;
  PreV[2] = fePrv2; PreI[2] = fePri2;
  PreV[3] = fePrv3; PreI[3] = fePri3;
  PreV[4] = fePrv4; PreI[4] = fePri4;
  PreV[5] = fePrv5; PreI[5] = fePri5;
  PreV[6] = fePrv6; PreI[6] = fePri6;
  PreV[7] = fePrv7; PreI[7] = fePri7;
  PreV[8] = fePrv8; PreI[8] = fePri8;
  PreV[9] = fePrv9; PreI[9] = fePri9;

  Calib[0] = feCalVp1; Calib[1] = feCalVc1;
  Calib[2] = feCalVp2; Calib[3] = feCalVc2;
  Calib[4] = feCalIp1; Calib[5] = feCalIc1;
  Calib[6] = feCalIp2; Calib[7] = feCalIc2; Calib[8] = feCalDef;
  Calib[9] = feCalVm1; Calib[10] = feCalVm2;
  Calib[11] = feCalIm1; Calib[12] = feCalIm2;

  Lock = 0;
  
  btReloadClick(NULL);
}

//-------------------------- Display K and S: -------------------------------

void __fastcall TSettingsForm::UpdateKS(void)
{
  double dp, dc;
  dp = feCalVp2->Value - feCalVp1->Value;
  dc = feCalVc2->Value - feCalVc1->Value;
  if(dc == 0) dc = 1;
  feVk->Value = MAX_CODE / MAX_V * dp / dc;
  feVs->Value = feVk->Value * feCalVc1->Value / MAX_CODE - feCalVp1->Value / MAX_V;

  dp = feCalIp2->Value - feCalIp1->Value;
  dc = feCalIc2->Value - feCalIc1->Value;
  if(dc == 0) dc = 1;
  feIk->Value = MAX_CODE / MAX_I * dp / dc;
  feIs->Value = feIk->Value * feCalIc1->Value / MAX_CODE - feCalIp1->Value / MAX_I;

  dp = feCalVp2->Value - feCalVp1->Value;
  dc = feCalVm2->Value - feCalVm1->Value;
  if(dc == 0) dc = 1;
  feVmk->Value = MAX_CODE / MAX_V * dp / dc;
  feVms->Value = feVmk->Value * feCalVm1->Value / MAX_CODE - feCalVp1->Value / MAX_V;

  dp = feCalIp2->Value - feCalIp1->Value;
  dc = feCalIm2->Value - feCalIm1->Value;
  if(dc == 0) dc = 1;
  feImk->Value = MAX_CODE / MAX_I * dp / dc;
  feIms->Value = feImk->Value * feCalIm1->Value / MAX_CODE - feCalIp1->Value / MAX_I;
}

//----------------------------- Form close: ---------------------------------

void __fastcall TSettingsForm::FormClose(TObject *Sender,
      TCloseAction &Action)
{
  if(ModalResult == mrOk)
  {
    MainForm->FAutoConnect = cbAutoConnect->Checked;
    MainForm->FAutoLoad = cbAutoLoad->Checked;
    MainForm->FSample = cbSample->ItemIndex * 20 + 20;
    MainForm->FAutoScroll = cbAutoScroll->Checked;
    MainForm->MaxV = feMaxV->Value;
    MainForm->MaxI = feMaxI->Value;
  }
  Action = caFree;
  SettingsForm = NULL;
}

//--------------------------- Set Default: ----------------------------------

void __fastcall TSettingsForm::btDefaultClick(TObject *Sender)
{
  cbAutoConnect->Checked = 1;
  cbAutoLoad->Checked = 1;
  cbSample->ItemIndex = (100 - 20) / 20;
  cbAutoScroll->Checked = 1;
}

//------------------------------- ESC: --------------------------------------

void __fastcall TSettingsForm::FormKeyPress(TObject *Sender, char &Key)
{
  if (Key == VK_ESCAPE)
   ModalResult = mrCancel;
}

//------------------------------ Cancel: ------------------------------------

void __fastcall TSettingsForm::btCancelClick(TObject *Sender)
{
  ModalResult = mrCancel;
}

//-------------------------------- OK: --------------------------------------

void __fastcall TSettingsForm::btOkClick(TObject *Sender)
{
  ModalResult = mrOk;
}

//----------------------------- Check Box: ----------------------------------

void __fastcall TSettingsForm::cbPAR_LOCKClick(TObject *Sender)
{
  if(!Lock)
  {
    TCheckBox *cb = (TCheckBox*)Sender;
    if(MainForm->FConnected)
      MainForm->WakePort->SetPar(cb->Tag, cb->Checked);
  }
}

//----------------------------- Combo Box: ----------------------------------

void __fastcall TSettingsForm::cbPAR_SNDChange(TObject *Sender)
{
  if(!Lock)
  {
    TComboBox *cb = (TComboBox*)Sender;
    if(MainForm->FConnected)
      MainForm->WakePort->SetPar(cb->Tag, cb->ItemIndex);
  }
}

//----------------------------- Float Edit: ---------------------------------

void __fastcall TSettingsForm::fePAR_DELChanged(TObject *Sender)
{
  if(!Lock)
  {
    TFloatEdit *fe = (TFloatEdit*)Sender;
    double v = fe->Value;
    if(fe->Tag == PAR_OTP) v = v * 10;
    if(fe->Tag == PAR_FNL) v = v * 10;
    if(fe->Tag == PAR_FNH) v = v * 10;
    if(fe->Tag == PAR_OVP) v = v * 100;
    if(fe->Tag == PAR_OCP) v = v * 1000;
    if(fe->Tag == PAR_OPP) v = v * 10;
    if(MainForm->FConnected)
      MainForm->WakePort->SetPar(fe->Tag, ROUND(v));
  }
}

//----------------------------- Time edit: -----------------------------------

void __fastcall TSettingsForm::edPAR_TIMExit(TObject *Sender)
{
  unsigned short tm_h, tm_m, tm_s, tm_ms;
  TDateTime tm = StrToDateTime(edPAR_TIM->Text);
  tm.DecodeTime(&tm_h, &tm_m, &tm_s, &tm_ms);
  int v = tm_h * 3600 + tm_m * 60 + tm_s;
  if(MainForm->FConnected)
    MainForm->WakePort->SetPar(PAR_TIM, v);
}

void __fastcall TSettingsForm::edPAR_TIMKeyPress(TObject *Sender,
      char &Key)
{
  if(Key == VK_RETURN) //ENTER
    edPAR_TIMExit(edPAR_TIM);
}

//-------------------------------- TOP: -------------------------------------

void __fastcall TSettingsForm::feMaxVChanged(TObject *Sender)
{
  if(!Lock)
  {
    if(MainForm->FConnected)
     MainForm->WakePort->SetVIPmax(ROUND(feMaxV->Value * 100),
       ROUND(feMaxI->Value * 1000),
       ROUND(feMaxP->Value * 10));
  }
}

//---------------------------- Save Preset: ---------------------------------

void __fastcall TSettingsForm::fePrv0Changed(TObject *Sender)
{
  if(!Lock)
  {
    TFloatEdit *fe = (TFloatEdit*)Sender;
    int n = fe->Tag;
    if(MainForm->FConnected)
      MainForm->WakePort->SetPre(n, ROUND(PreV[n]->Value * 100),
        ROUND(PreI[n]->Value * 1000));
  }
}

//--------------------------- Apply Preset: ---------------------------------

void __fastcall TSettingsForm::btPre0Click(TObject *Sender)
{
  TButton *bt = (TButton*)Sender;
  int n = bt->Tag;
  if(MainForm->FConnected)
    MainForm->WakePort->SetVI(ROUND(PreV[n]->Value * 100),
      ROUND(PreI[n]->Value * 1000), 0);
}

//--------------------------- Apply Calib: ----------------------------------

void __fastcall TSettingsForm::feCalVp1Changed(TObject *Sender)
{
  if(!Lock)
  {
    TFloatEdit *fe = (TFloatEdit*)Sender;
    int n = fe->Tag;
    int v = fe->Value;
    if(n == CAL_VP1 || n == CAL_VP2) v = ROUND(fe->Value * 100);
    if(n == CAL_IP1 || n == CAL_IP2) v = ROUND(fe->Value * 1000);
    if(MainForm->FConnected)
      MainForm->WakePort->SetCal(n, v);
    UpdateKS();
  }
}

//---------------------------- Load Params: ---------------------------------

void __fastcall TSettingsForm::btReloadClick(TObject *Sender)
{
  Lock = 1;
  TCursor Save_Cursor = Screen->Cursor;
  if(MainForm->FConnected)
  {
    Screen->Cursor = crHourGlass;

    cbPAR_LOCK->Checked  = ReadPar(cbPAR_LOCK->Tag);
    fePAR_OVP->Value     = ReadPar(fePAR_OVP->Tag) / 100.0;
    fePAR_OCP->Value     = ReadPar(fePAR_OCP->Tag) / 1000.0;
    fePAR_OPP->Value     = ReadPar(fePAR_OPP->Tag) / 10.0;
    fePAR_DEL->Value     = ReadPar(fePAR_DEL->Tag);
    fePAR_OTP->Value     = ReadPar(fePAR_OTP->Tag) / 10.0;
    fePAR_FNL->Value     = ReadPar(fePAR_FNL->Tag) / 10.0;
    fePAR_FNH->Value     = ReadPar(fePAR_FNH->Tag) / 10.0;
    cbPAR_TRC->ItemIndex = ReadPar(cbPAR_TRC->Tag);
    cbPAR_CON->Checked   = ReadPar(cbPAR_CON->Tag);
    cbPAR_POW->Checked   = ReadPar(cbPAR_POW->Tag);
    cbPAR_SET->Checked   = ReadPar(cbPAR_SET->Tag);
    cbPAR_GET->Checked   = ReadPar(cbPAR_GET->Tag);
    cbPAR_APV->ItemIndex = ReadPar(cbPAR_APV->Tag);
    cbPAR_APC->ItemIndex = ReadPar(cbPAR_APC->Tag);
    cbPAR_PRC->Checked   = ReadPar(cbPAR_PRC->Tag);
    cbPAR_DNP->Checked   = ReadPar(cbPAR_DNP->Tag);
    cbPAR_OUT->Checked   = ReadPar(cbPAR_OUT->Tag);
    cbPAR_SND->ItemIndex = ReadPar(cbPAR_SND->Tag);
    cbPAR_ENR->Checked   = ReadPar(cbPAR_ENR->Tag);
    cbPAR_SPL->Checked   = ReadPar(cbPAR_SPL->Tag);
    fePAR_INF->Value     = ReadPar(fePAR_INF->Tag) / 100.0;

    int t = ReadPar(edPAR_TIM->Tag);
    TDateTime tm = EncodeTime(t / 3600, (t % 3600) / 60, (t % 3600) % 60, 0);
    edPAR_TIM->Text = tm.FormatString("hh:mm:ss");

    int v, i, p;
    MainForm->WakePort->GetVIPmax(v, i, p);
    feMaxV->Value = v / 100.0;
    feMaxI->Value = i / 1000.0;
    feMaxP->Value = p / 10.0;

    for(int n = 0; n < PRESETS; n++)
    {
      MainForm->WakePort->GetPre(n, v, i);
      PreV[n]->Value = v / 100.0;
      PreI[n]->Value = i / 1000.0;
    }

    double k;
    for(int n = 0; n < CALIBS; n++)
    {
      MainForm->WakePort->GetCal(n, v);
      k = v;
      if(n == CAL_VP1 || n == CAL_VP2) k = k / 100.0;
      if(n == CAL_IP1 || n == CAL_IP2) k = k / 1000.0;
      Calib[n]->Value = k;
    }

    Screen->Cursor = Save_Cursor;
  }
  UpdateKS();
  Lock = 0;
}

//---------------------------------------------------------------------------

