#include <vcl.h>
#pragma hdrstop

#include "Connect.h"
#include "Main.h"

#pragma package(smart_init)
#pragma resource "*.dfm"

TConnectForm *ConnectForm;

//---------------------------------------------------------------------------

__fastcall TConnectForm::TConnectForm(TComponent* Owner, int *PortNumber)
  : TForm(Owner)
{
  FPortNumber = PortNumber;
}

//---------------------------------------------------------------------------

void __fastcall TConnectForm::FormCreate(TObject *Sender)
{
  TCursor Save_Cursor = Screen->Cursor;
  TStringList *APortBox = new TStringList;
  try
  {
    Screen->Cursor = crHourGlass;
    if(*FPortNumber) MainForm->WakePort->Close();
    bool Selected = 0;
    MainForm->WakePort->GetPortList(APortBox);
    for (int i = 0; i < APortBox->Count; i++)
      try
      {
        TListItem *pListItem = DevListView->Items->Add();
        pListItem->Caption = APortBox->Strings[i];
        pListItem->SubItems->Add("None");
        MainForm->WakePort->Open(APortBox->Strings[i]);
        pListItem->SubItems->Strings[0] = MainForm->WakePort->GetInfo(0);
        if(!Selected) { DevListView->Selected = pListItem; Selected = 1; }
        MainForm->WakePort->Close();
      }
      catch(const EInOutError &e) { MainForm->WakePort->Close(); }
  }
  __finally { Screen->Cursor = Save_Cursor; delete APortBox; }
}

//---------------------------------------------------------------------------

void __fastcall TConnectForm::FormClose(TObject *Sender,
      TCloseAction &Action)
{
  Action = caFree;
  ConnectForm = NULL;
}

//---------------------------------------------------------------------------

void __fastcall TConnectForm::FormKeyPress(TObject *Sender, char &Key)
{
  if (Key == VK_ESCAPE)
   ModalResult = mrCancel;
}

//---------------------------------------------------------------------------

void __fastcall TConnectForm::btOkClick(TObject *Sender)
{
  int i = DevListView->ItemIndex;
  if(i >= 0 && i < DevListView->Items->Count)
  {
    AnsiString pPortName = DevListView->Items->Item[i]->Caption;
    *FPortNumber = MainForm->WakePort->NameToNumber(pPortName);
  }
  else *FPortNumber = 0;
  Close();
}

//---------------------------------------------------------------------------

void __fastcall TConnectForm::btCancelClick(TObject *Sender)
{
  Close();
}

//---------------------------------------------------------------------------

