#ifndef ConnectH
#define ConnectH

#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ExtCtrls.hpp>
#include <ComCtrls.hpp>

//---------------------------------------------------------------------------

class TConnectForm : public TForm
{
__published:	// IDE-managed Components
  TButton *btCancel;
  TButton *btOk;
  TListView *DevListView;
  void __fastcall FormCreate(TObject *Sender);
  void __fastcall FormClose(TObject *Sender, TCloseAction &Action);
  void __fastcall FormKeyPress(TObject *Sender, char &Key);
  void __fastcall btOkClick(TObject *Sender);
  void __fastcall btCancelClick(TObject *Sender);
private:	// User declarations
  int *FPortNumber;
public:		// User declarations
  __fastcall TConnectForm(TComponent* Owner, int *PortNumber);
};

//---------------------------------------------------------------------------

extern PACKAGE TConnectForm *ConnectForm;

//---------------------------------------------------------------------------

#endif
